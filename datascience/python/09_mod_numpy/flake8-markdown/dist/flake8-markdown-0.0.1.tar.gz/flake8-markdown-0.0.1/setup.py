# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['flake8_markdown']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'flake8-markdown',
    'version': '0.0.1',
    'description': 'Links Python Code Blocks in Markdown Using Flake8',
    'long_description': None,
    'author': 'GS Jackson',
    'author_email': 'gary.jackson@qlx.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/enterlifeonline',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
